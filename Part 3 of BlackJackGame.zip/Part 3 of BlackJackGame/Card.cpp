#include "Card.h"

// Constructor implementation
Card::Card(std::string s, std::string r) : suit(s), rank(r) {}

//Accessor implementation
std::string Card::getSuit() const 
{
    return suit;
}

std::string Card::getRank() const 
{
    return rank;
}

int Card::getRankValue() const 
{
    if (rank == "Jack" || rank == "Queen" || rank == "King") {
        return 10;
    }
    else if (rank == "Ace") {
        return 11; // Assuming Ace's value is 11, can be adjusted if needed
    }
    else {
        return std::stoi(rank); // Convert rank to integer (assuming ranks are numeric)
    }
}