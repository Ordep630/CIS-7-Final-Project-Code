#ifndef CARD_H
#define CARD_H

#include <string>

class Card 
{
private:
    std::string suit;       // Represents the suit of the card
    std::string rank;       // Represents the rank of the card ("Jack", "7", "Queen" etc.)

public:
    //Constructor to initialize a card with a suit and rank
    Card(std::string s, std::string r);

    // Accessors methods to retrieve the suit and rank of the card
    std::string getSuit() const;
    std::string getRank() const;
    int getRankValue() const;   //declaration for rank value
};

#endif // CARD_H