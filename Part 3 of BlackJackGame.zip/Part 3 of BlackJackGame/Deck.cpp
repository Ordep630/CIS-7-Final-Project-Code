#include "Deck.h"
#include <cstdlib>

//Adds a card to the deck
void Deck::addCard(const Card &card) 
{
    cards.push_back(card);
}

// Draws a card from the deck
Card Deck::drawCard() 
{
    if (!cards.empty()) 
    {
        Card drawnCard = cards.back();  // Get the top card from the deck
        cards.pop_back();               // Remove the drawn card from the deck
        return drawnCard;
    }
    return Card("", "");    // Returning a default-constructed card if the deck is empty
}


const std::vector<Card>& Deck::getCards() const
{
    return cards;
}

int Deck::cardsRemaining() const 
{
    return cards.size();
}