#ifndef DECK_H
#define DECK_H

#include "Card.h"
#include <vector>

class Deck 
{
private:
    std::vector<Card> cards;    // Holds a collection of cards representing the deck

public:
    Deck();

    // Adds a card to the deck
    void addCard(const Card &card);

    // Draws a card from the deck
    Card drawCard();

    const std::vector<Card>& getCards() const;  // Decleration for getCards
    int cardsRemaining() const;     // Declare for cardsRemaining
};

#endif // DECK_H