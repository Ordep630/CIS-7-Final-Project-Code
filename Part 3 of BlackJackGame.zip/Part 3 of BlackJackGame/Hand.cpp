#include "Hand.h"
#include <cstdlib>

// Adds a card to the hand
void Hand::addCard(const Card &card) 
{
    cards.push_back(card);
}

//Calculates the total value of the hand considering card ranks and Aces
int Hand::calculateHandValue() const 
{
    int value = 0;
    int aceCount = 0;

    for (const auto& card : cards) 
    {
        if (card.getRank() == "Jack" || card.getRank() == "Queen" || card.getRank() == "King") 
        {
            value += 10;    // Face cards have a value of 10
        }
        else if (card.getRank() == "Ace") 
        {
            value += 11;    // Aces initially count as 11
            aceCount++;     // Count the number of aces in the hand
        }
        else 
        {
            value += std::stoi(card.getRank());     // Add numeric card values
        }
    }
    // Adjust the value if there are aces and the total exceeds 21
    while (value > 21 && aceCount > 0) 
    {
        value -= 10;    // Change an ace's value from 11 to 1
        aceCount--;     // Decrement the count of usable aces
    }

    return value;       // Return the total value of the hand
}