#ifndef HAND_H
#define HAND_H

#include "Card.h"
#include <vector>

class Hand 
{
private:
    std::vector<Card> cards;    // Represents the cards in a player's hand

public:
    // Adds a card to the hand
    void addCard(const Card &card);

    // Calculate the total value of the hand
    int calculateHandValue() const;
};

#endif // HAND_H