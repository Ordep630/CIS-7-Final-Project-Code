#include <iostream>
#include <string>
#include "Deck.h"
#include "Hand.h"
using namespace std;

// Function prototypes
void dealerTurn(Deck&, Hand&);
double DealerWinProbability(const Hand&, const Hand&, const Deck&);
void evaluateGameResult(const Hand&, const Hand&);

int main() 
{
    int playerWinsCount = 0;
    int dealerWinsCount = 0;
    int pushCount = 0;

    bool playAgain = true;

    while (playAgain) 
    {
        // Initialize the deck and shuffle cards
        Deck deck;
        // ... (Add cards to the deck and shuffle)

        // Deal cards to the player and dealer
        Hand playerHand;
        Hand dealerHand;

        // ... (Deal initial cards to the player and dealer)

        // Simulate player's turn (player actions, hitting, standing, etc.)
        // ... (Code to simulate player's turn)

        // Simulate dealer's turn
        dealerTurn(deck, dealerHand);

        // Estimate the probability of dealer's hand winning against player's hand
        double probabilityDealerWins = DealerWinProbability(dealerHand, playerHand, deck);

        // Display the estimated probability
        cout << "Estimated probability of dealer winning: " << probabilityDealerWins << endl;

        // Evaluate game result and update probabilities
        evaluateGameResult(playerHand, dealerHand);

        // Display counts
        cout << "Player wins count: " << playerWinsCount << endl;
        cout << "Dealer wins count: " << dealerWinsCount << endl;
        cout << "Push (Draw) count: " << pushCount << endl;

        // Ask the user if they want to play again or exit
        string playChoice;
        cout << "Would you like to play again? (yes/no): ";
        cin >> playChoice;

        // Check user input to decide whether to continue playing or exit
        if (playChoice == "no" || playChoice == "No" || playChoice == "NO")
        {
            playAgain = false; // Set playAgain flag to false to exit the loop
        }
        else 
        {
            cout << "Let's play again!\n\n";
        }
    }

    // Display a friendly goodbye message
    cout << "Thank you for playing BlackJack! \n\n";

    return 0;
}

// Function to simulate the dealer's turn according to the fixed strategy
void dealerTurn(Deck& deck, Hand& dealerHand)
{
    int dealerValue = dealerHand.calculateHandValue();

    // Continue to draw cards until the dealer's hand value reaches 17 or higher
    while (dealerValue < 17)
    {
        Card drawnCard = deck.drawCard();   // Draw a card from the deck
        dealerHand.addCard(drawnCard);      // Add the drawn card to the dealer's hand
        dealerValue = dealerHand.calculateHandValue();  // Recalculate the hand value
        // At this point, if the dealer's hand value is 17 or higher, the loop will end
        // If it's still below 17, the loop continues until the condition is met
        // The dealer must hit according to the fixed strategy (hit on 16 or less, stand on 17 or more)
    }
}

// Function to estimate the probability of dealer's hand winning against player's hand
double DealerWinProbability(const Hand &dealerHand, const Hand &playerHand, const Deck &deck)
{
    int playerValue = playerHand.calculateHandValue();
    int dealerValue = dealerHand.calculateHandValue();

    int countDealerWins = 0;
    int countTotal = 0;

    // Remaining unknown cards in the deck
    int remainingCards = deck.cardsRemaining();

    // Loop through possible card values for dealer to reach 17 or higher
    for (int i = 17; i <= 21; ++i)
    {
        // Calculate how many cards can make the dealer's hand reach or exceed i
        int count = 0;
        for (const auto& card : deck.getCards())
        {
            if (card.getRankValue() + dealerValue <= i)
            {
                count++;
            }
        }

        // Update counters based on comparison with player's hand
        if (i > playerValue && i <= 21)
        {
            countDealerWins += count;
        }
        countTotal += count;
    }

    // Calculate estimated probability of dealer's hand winning
    double probabilityDealerWins = static_cast<double>(countDealerWins) / remainingCards;

    return probabilityDealerWins;
}

// Function to evaluate the game result and update probabilities
void evaluateGameResult(const Hand& playerHand, const Hand& dealerHand)
{
    // Variables to represent probability counters, 
    int playerWinsCount = 0;
    int dealerWinsCount = 0;
    int pushCount = 0;

    int playerValue = playerHand.calculateHandValue();
    int dealerValue = dealerHand.calculateHandValue();

    if (playerValue > 21) {
        std::cout << "Player busts. Dealer wins.\n";
        dealerWinsCount++; // Increment the counter for dealer wins
    }
    else if (dealerValue > 21) {
        std::cout << "Dealer busts. Player wins.\n";
        playerWinsCount++; // Increment the counter for player wins
    }
    else if (playerValue > dealerValue) {
        std::cout << "Player wins.\n";
        playerWinsCount++; // Increment the counter for player wins
    }
    else if (playerValue < dealerValue) {
        std::cout << "Dealer wins.\n";
        dealerWinsCount++; // Increment the counter for dealer wins
    }
    else {
        std::cout << "Push. It's a tie.\n";
        pushCount++; // Increment the counter for push (tie)
    }

}